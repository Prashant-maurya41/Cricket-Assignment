def batting_points(runs, balls, fours, sixes):
    points = 0

    points += runs // 2

    if runs >= 100:
        points += 10
    elif runs >= 50:
        points += 5

    strike_rate = (runs / balls) * 100
    if 80 <= strike_rate <= 100:
        points += 2
    elif strike_rate >= 100:
        points += 4

    points += fours
    points += sixes*2

    return points

def bowling_points(wickets, runs_given, overs):
    points = 0

    points += wickets*10

    if wickets >= 5:
        points += 10
    elif wickets >= 3:
        points += 5

    economy = runs_given / overs
    if economy < 2:
            points += 10
    elif 2 <= economy < 3.5:
            points += 7
    elif 3.5 <= economy < 4.5:
            points += 4

    return points





