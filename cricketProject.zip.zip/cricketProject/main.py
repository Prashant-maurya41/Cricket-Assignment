from modules.cricket_module import batting_points, bowling_points
print("Import successful")

players = [
    {"name" : "Virat kohli", "runs": 85, "balls": 98, "fours": 8, "sixes": 2},
    {"name": "du Plessis", "runs": 96, "balls": 85, "fours": 10, "sixes": 3},
    {"name": "Bhuvneshwar Kumar", "wickets": 1, "runs_given": 45, "overs": 10},
    {"name": "Yuzvendra chahal", "wickets": 2, "runs_given": 40, "overs": 10},
    {"name": "Kuldeep yadav", "wickets": 4, "runs_given": 35, "overs": 10}
]

highest_score = 0
man_of_match =""

for player in players:

    if "runs" in player:
        score = batting_points(
            player["runs"], player["balls"], player["fours"], player["sixes"]
        )
        print({"name": player["name"], "batscore": score})

    else:
        score = bowling_points(
            player["wickets"], player["runs_given"], player["overs"]
        )
        print({"name": player["name"], "bowlscore": score})

    if score > highest_score:
            highest_score = score
            man_of_match = player["name"]

print("\nMan of the match:", man_of_match)